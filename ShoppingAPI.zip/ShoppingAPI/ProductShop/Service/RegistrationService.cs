﻿using Demo009.Entity;
using Demo009.Model;
using Demo009.Service;
using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Demo009.Service
{
    public class RegistrationService : IRegistrationService
    {
        private readonly ProductContext _context;

        public RegistrationService(ProductContext context)
        {
            _context = context;
            var Register = new List<Registration>
                {
                    new Registration { UserName = "asha", Password = "1234#7 ", Email = "asha@gmail.com",PhoneNumber =1234568933,IsActive = true },
                    new Registration{ UserName = "vinusha", Password = "rty234*", Email = "vinusha@gmail.com",PhoneNumber = 7867933699,IsActive = true },
                    new Registration { UserName = "preksha", Password = "yuhbn897", Email = "preksha@gmail.com",PhoneNumber = 7836749490,IsActive = true },
                    new Registration { UserName = "pratiksha", Password = "6783km", Email = "pratiksha@gmail.com",PhoneNumber = 6578449080,IsActive =true  }
                };
            _context.registrations.AddRange(Register);
            _context.SaveChanges();
        }

        public ResponseModel Register(RegistrationModel userModel)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                if (_context.userlogins.Any(u => u.UserName == userModel.UserName || u.Email == userModel.Email))
                {
                    response.IsSuccess = false;
                    response.Message = "Username or email already exists.";
                    return response;
                }

                var newUser = new UserLogin
                {
                    UserId = userModel.UserId,
                    UserName = userModel.UserName,
                    Email = userModel.Email,
                    PhoneNumber = userModel.PhoneNumber,
                    Password = userModel.Password,
                    IsActive = true
                };

                _context.userlogins.Add(newUser);
                _context.SaveChanges();

                response.IsSuccess = true;
                response.Message = "User registration successful.";
            }
            catch (DbUpdateException ex)
            {
                response.IsSuccess = false;
                response.Message = $"Error: {ex.Message}"; 
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = $"Error: {ex.Message}";
            }

            return response;
        }

    }
}
