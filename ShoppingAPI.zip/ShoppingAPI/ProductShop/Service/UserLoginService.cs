﻿using Demo009.Entity;
using Demo009.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Demo009.Service
{
    public class UserLoginService : IUserLoginService
    {
        private readonly ProductContext _context;
        public UserLoginService(ProductContext context)
        {
            _context = context;
            var userlogin = new List<UserLogin>
                {
                    new UserLogin { UserName = "asha", Password = "1234#7 ", Email = "asha@gmail.com",PhoneNumber =1234568933,IsActive = true },
                    new UserLogin { UserName = "vinusha", Password = "rty234*", Email = "vinusha@gmail.com",PhoneNumber = 7867933699,IsActive = true },
                    new UserLogin { UserName = "preksha", Password = "yuhbn897", Email = "preksha@gmail.com",PhoneNumber = 7836749490,IsActive = true },
                    new UserLogin { UserName = "pratiksha", Password = "6783km", Email = "pratiksha@gmail.com",PhoneNumber = 6578449080,IsActive =true  }
                };
            _context.userlogins.AddRange(userlogin);
            _context.SaveChanges();
        }

        public ResponseModel Login(string username, string password)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                var user = _context.userlogins.FirstOrDefault(u => u.UserName == username && u.Password == password);

                if (user != null)
                {
                    response.IsSuccess = true;
                    response.Message = "Login successful.";
                }
                else
                {
                    response.IsSuccess = false;
                    response.Message = "Invalid username or password.";
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = $"Error: {ex.Message}";
            }

            return response;
        }

        public ResponseModel Register(RegistrationModel userModel)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                if (_context.userlogins.Any(u => u.UserName == userModel.UserName || u.Email == userModel.Email))
                {
                    response.IsSuccess = false;
                    response.Message = "Username or email already exists.";
                    return response;
                }

                var newUser = new UserLogin
                {
                    UserName = userModel.UserName,
                    Email = userModel.Email,
                    PhoneNumber = userModel.PhoneNumber,
                    Password = userModel.Password,
                    IsActive = true
                };

                _context.userlogins.Add(newUser);
                _context.SaveChanges();

                response.IsSuccess = true;
                response.Message = "User registration successful.";
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = $"Error: {ex.Message}";
            }

            return response;
        }

    }
}


