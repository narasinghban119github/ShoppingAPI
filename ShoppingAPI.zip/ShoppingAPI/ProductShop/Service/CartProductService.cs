﻿using Demo009.Entity;
using System;
using System.Collections.Generic;
using System.Linq;

public class CartProductService : ICartProductService
{
    private List<CartProduct> _cartproducts;
    private readonly ProductContext _context;
    public CartProductService(ProductContext context)
    {
        _context = context;
    
        var cartproducts = new List<CartProduct>
        {
            new CartProduct { ProductName = "Coffee Mug", Quantity = 1, Cost = 100 },
            new CartProduct { ProductName = "Hoodie", Quantity = 3, Cost = 999 },
            new CartProduct { ProductName = "Water Bottle", Quantity = 2, Cost = 200 }
        };
    }

    public List<CartProduct> GetAllCartProducts()
    {
        return _context.cartproducts.ToList();
    }

    public CartProduct GetCartProductById(int id)
    {
        return _context.cartproducts.FirstOrDefault(p => p.ProductId == id);
    }

    public void AddCartProduct(CartProduct cartProduct)
    {
        //cartProduct.ProductId = _cartProducts.Any() ? _cartProducts.Max(p => p.ProductId) + 1 : 1;
        _context.cartproducts.Add(cartProduct);
        _context.SaveChanges();
    }

    public void UpdateCartProduct(int id, CartProduct updatedCartProduct)
    {
        var existingcartProduct = _context.cartproducts.FirstOrDefault(p => p.ProductId == id);
        if (existingcartProduct != null)
        {
            existingcartProduct.ProductName = updatedCartProduct.ProductName;
            existingcartProduct.Quantity = updatedCartProduct.Quantity;
            existingcartProduct.Cost = updatedCartProduct.Cost;
            _context.cartproducts.Update(existingcartProduct);
            _context.SaveChanges();
        }
        else
        {
            throw new InvalidOperationException("Cart product not found");
        }
    }

    public void DeleteCartProduct(int id)
    {
        var cartProduct = _context.cartproducts.FirstOrDefault(p => p.ProductId == id);
        if (cartProduct != null)
        {
            _context.cartproducts.Remove(cartProduct);
            _context.SaveChanges();
        }
        else
        {
            throw new InvalidOperationException("Cart product not found");
        }
    }
}
