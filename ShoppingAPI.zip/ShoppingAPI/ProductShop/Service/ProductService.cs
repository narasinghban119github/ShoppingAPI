﻿using Demo009;
using Demo009.Entity;
using Demo009.Service;
using System;
using System.Collections.Generic;
using System.Linq;

public class ProductService : IProductService
{
    private List<Product> _products;
    private readonly ProductContext _context;
    public ProductService(ProductContext context)
    {
        _context = context;
    
        var product = new List<Product>
        {
            new Product {  ProductName = "T-Shirt", Quantity = 2, Cost = 199 },
            new Product {  ProductName = "Coffee Mug",Quantity= 1, Cost = 100 },
            new Product {  ProductName = "Hoodie", Quantity=3, Cost=999 },
            new Product {  ProductName = "Water Bottle",Quantity=2, Cost= 200 }
        };
        
    }

    public List<Product> GetAllProducts()
    {
        return _context.products.ToList();
    }

    public Product GetProductById(int id)
    {
        return _context.products.FirstOrDefault(p => p.ProductId == id);
    }

    public void AddProduct(Product product)
    {
        //product.ProductId = _products.Any() ? _products.Max(p => p.ProductId) + 1 : 1;
        _context.products.Add(product);
        _context.SaveChanges();
    }

    public void UpdateProduct(int id, Product updatedProduct)
    {
        var existingProduct = _products.FirstOrDefault(p => p.ProductId == id);
        if (existingProduct != null)
        {
            existingProduct.ProductName = updatedProduct.ProductName;
            existingProduct.Cost = updatedProduct.Cost;
            _context.products.Update(existingProduct);
            _context.SaveChanges();
        }
        else
        {
            throw new InvalidOperationException("Product not found");
        }
    }

    public void DeleteProduct(int id)
    {
        var product = _products.FirstOrDefault(p => p.ProductId == id);
        if (product != null)
        {
            _context.products.Remove(product);
            _context.SaveChanges();
        }
        else
        {
            throw new InvalidOperationException("Product not found");
        }
    }
}
