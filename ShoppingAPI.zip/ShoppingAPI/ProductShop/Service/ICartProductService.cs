﻿using Demo009.Entity;

public interface ICartProductService
{
    List<CartProduct> GetAllCartProducts();
    CartProduct GetCartProductById(int id);
    void AddCartProduct(CartProduct cartProduct);
    void UpdateCartProduct(int id, CartProduct cartProduct);
    void DeleteCartProduct(int id);
}
