﻿using Demo009.Model;

namespace Demo009.Service
{
     public interface IUserLoginService
     {
         
            ResponseModel Login(string username, string password);
           
     }

}






