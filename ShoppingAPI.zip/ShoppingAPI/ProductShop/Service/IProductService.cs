﻿using Demo009;
using Demo009.Entity;
using System.Collections.Generic;

public interface IProductService
{
    List<Product> GetAllProducts();
    Product GetProductById(int id);
    void AddProduct(Product product);
    void UpdateProduct(int id, Product updatedProduct);
    void DeleteProduct(int id);
}
