﻿using Demo009.Entity;
using Demo009.Model;

namespace Demo009.Service
{
    public interface  IRegistrationService
    {
        ResponseModel Register(RegistrationModel userModel);
        
    }
}
