﻿using System;
using System.Linq;
using Demo009.Entity;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class CartProductController : ControllerBase
{
    private readonly ICartProductService _cartProductService;

    public CartProductController(ICartProductService cartProductService)
    {
        _cartProductService = cartProductService;
    }

    [HttpGet]
    public IActionResult GetAllCartProducts()
    {
        var cartProducts = _cartProductService.GetAllCartProducts();
        return Ok(cartProducts);
    }

    [HttpGet("{id}")]
    public IActionResult GetCartProductById(int id)
    {
        var cartProduct = _cartProductService.GetCartProductById(id);
        if (cartProduct == null)
            return NotFound();
        return Ok(cartProduct);
    }

    [HttpPost]
    public IActionResult AddCartProduct([FromBody] CartProduct cartProduct)
    {
        try
        {
            _cartProductService.AddCartProduct(cartProduct);
            return CreatedAtAction(nameof(GetCartProductById), new { id = cartProduct.ProductId }, cartProduct);
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    [HttpPut("{id}")]
    public IActionResult UpdateCartProduct(int id, [FromBody] CartProduct cartProduct)
    {
        if (id != cartProduct.ProductId)
            return BadRequest("Id mismatch");

        try
        {
            _cartProductService.UpdateCartProduct(id, cartProduct);
            return NoContent();
        }
        catch (InvalidOperationException)
        {
            return NotFound();
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteCartProduct(int id)
    {
        try
        {
            _cartProductService.DeleteCartProduct(id);
            return NoContent();
        }
        catch (InvalidOperationException)
        {
            return NotFound();
        }
    }
}
