﻿using Demo009.Service;
using Microsoft.AspNetCore.Mvc;
using System;

namespace Demo009.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserLoginController : ControllerBase
    {
        private readonly IUserLoginService _userLoginService;

        public UserLoginController(IUserLoginService userLoginService)
        {
            _userLoginService = userLoginService;
        }

        [HttpPost]
        [Route("[action]")]
        public IActionResult Login(string username, string password)
        {
            try
            {
                var response = _userLoginService.Login(username, password);
                if (response.IsSuccess)
                    return Ok(response);
                else
                    return BadRequest(response.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
