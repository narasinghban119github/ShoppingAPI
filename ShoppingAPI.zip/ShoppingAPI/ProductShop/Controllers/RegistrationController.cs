﻿using Demo009.Model;
using Demo009.Service;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class RegistrationController : ControllerBase
{
    private readonly IRegistrationService _registrationService;

    public RegistrationController(IRegistrationService registrationService)
    {
        _registrationService = registrationService;
    }

    [HttpPost]
    [Route("[action]")]
    public IActionResult Register(RegistrationModel userModel)
    {
        try
        {
            var response = _registrationService.Register(userModel);
            if (response.IsSuccess)
                return Ok(response);
            else
                return BadRequest(response.Message);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }
}
    