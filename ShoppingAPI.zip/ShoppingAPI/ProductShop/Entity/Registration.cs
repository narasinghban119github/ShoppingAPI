﻿using System.ComponentModel.DataAnnotations;

namespace Demo009.Entity
{
    public class Registration
    {
        [Key]
        public int UserID { get; set; }
        public string UserName { get; set; }

        public string Email { get; set; }
        public string Password { get; set; }
        public long PhoneNumber {  get; set; } 
        public bool IsActive { get; set; }
        
    }
}
