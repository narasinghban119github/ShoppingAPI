﻿using System.ComponentModel.DataAnnotations;

namespace Demo009.Entity
{
   
        public class UserLogin
        {
            [Key]
            public int? UserId { get; set; }

            [Required]
            [MaxLength(50)]
            public string? UserName { get; set; }

            [Required]
            [MaxLength(100)]
            [EmailAddress]
            public string? Email { get; set; }

            [Required]
            [MaxLength(20)]
            [Phone]
            public long? PhoneNumber { get; set; }

            [Required]
            [MaxLength(100)]
            public string? Password { get; set; }

            public bool? IsActive { get; set; }

       
    }

}


