﻿using System.ComponentModel.DataAnnotations;

namespace Demo009.Entity
{
    public class CartProduct
    {
        [Key]
        public int CartId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal Cost { get; set; }

    }
}
