﻿using System.ComponentModel.DataAnnotations;

namespace Demo009
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; } 
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal Cost { get; set; }
    }
}
